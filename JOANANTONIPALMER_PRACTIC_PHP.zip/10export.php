<?php
$fp = fopen("students.txt","w");
$db = mysqli_connect("localhost","root","","students");
if ($rs = $db->query("SELECT * FROM students"))
{
  while ($row = $rs->fetch_assoc())
  {
    fputtxt($fp, $row);
  }
  $rs->close();
}
fclose($fp);