<!DOCTYPE html>
<html>
<head>
	<title>Data Base</title>
	<style>
	</style>
</head>
<body>
	<h1>Order By</h1>
	<form method="get">
		<select name="order">
			<option value="asc">ASC POSITION</option>
			<option value="desc">DESC POSITION</option>
		</select>
		<input type="submit" value="ORDENA"/>
	</form>
	<?php
	// Create connection 
	include("01connect.php");
	// Operate over Data Base
	// ......................................//
	$sql="SELECT name, surname, age, sex FROM student";
	if(isset($_REQUEST['order'])){
		$sql.= " ORDER BY age ".$_REQUEST['order']; 
	}
	echo "<p>".$sql."</p>";
	// Select table 
	echo "<table border='1'>";
	echo "<tr><th>AGE</th><th>NAME</th><th>SURNAME</th></th><th>SEX</th></tr>";
	$rs = mysqli_query($con,$sql);
	while($row=mysqli_fetch_array($rs)){
		echo "<tr>";
			echo "<td>".$row['age']."</td>";
			echo "<td>".$row['name']."</td>";
			echo "<td>".$row['surname']."</td>";
			echo "<td>".$row['sex']."</td>";
		echo "</tr>";
	}
	echo "</table>";
	// ......................................//
	// Close connection
	mysqli_close($con);
	?>
</body>
</html>