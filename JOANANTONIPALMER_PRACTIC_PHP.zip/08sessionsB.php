<?php
session_start();
?>
<html>
<head>
<title>User Login</title>
</head>
<body>

<?php

if($_REQUEST["user"]=='paco') {
	echo "Hello Paco, Welcome!!";
} else {
	echo "Hello user, Welcome!!";
}

?>
<br><br>Click here to <a href="08sessionsC.php" tite="Logout">Logout.

</body>
</html>