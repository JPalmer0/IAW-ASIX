<?php
session_start();
unset($_SESSION["user"]);
echo "You succefully logged out.";
?>