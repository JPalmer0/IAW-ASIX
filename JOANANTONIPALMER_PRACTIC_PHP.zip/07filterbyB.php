<!DOCTYPE html>
<html>
<head>
	<title>Filter By</title>
	<style>
	</style>
</head>
<body>
	<h1>Filter BY</h1>
	<?php
	include("01connect.php");
	$sexe=$_REQUEST['sex'];


	if ($sexe == "All") {
		$sql="SELECT * FROM student";
		} else {
			$sql="SELECT * FROM student
			WHERE sex='$sexe'";
		}
	 
	echo $sql;
	$rs = mysqli_query($con,$sql);

	return $sql;
	
	mysqli_close($con);
	?>
</body>
</html>