<!DOCTYPE html>
<html>
<head>
	<title>Data Base</title>
	<style>
	</style>
</head>
<body>
	<h1>UPDATEPHP.</h1>
	<form action="03updateformB.php" method="GET">
		<?php
			include("01connect.php");
			echo "student:<select name='student'>";
			$sql="SELECT id, name FROM student"; 
			$rs = mysqli_query($con,$sql);
			while($row=mysqli_fetch_array($rs)){
				echo "<option value='".$row['id']."'>";
					echo $row['name'];
				echo "</option>";
			}
			echo "</select>";
		?><br/>
		NAME:<input type="text" name="name"/><br/>
		SURNAME:<input type="text" name="surname"/><br/>
		AGE:<input type="number" name="age"/><br/>
		SEX:<select name="sex">
			<option value="man">MAN</option>
			<option value="woman">WOMAN</option>
		</select><br/>
		<input type="submit" value="SEND"/>
	</form>
</body>
</html>