<!DOCTYPE html>
<html>
<head>
	<title>Data Base</title>
	<style>
	</style>
</head>
<body>
	<h1>Connect Data Base (PHP).</h1>
	<?php
	// Create connection 
	include("01connect.php");
	// Operate over Data Base
	// ......................................//
	// Insert table 
	$name = $_REQUEST['name'];
	$surname = $_REQUEST['surname'];
	$age = $_REQUEST['age'];
	$sex = $_REQUEST['sex'];
	$sql="INSERT INTO student (name, surname, age, sex) values ('$name', '$surname', '$age', '$sex')"; 
	if (mysqli_query($con,$sql))  {  
		echo "Inserted row successfully";  
	} else  {  
		echo "Error inserting row: " . mysqli_error($con);  
	} 
	// ......................................//
	mysqli_close($con);
	?>
</body>
</html>