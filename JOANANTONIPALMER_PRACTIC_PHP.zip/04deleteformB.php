<!DOCTYPE html>
<html>
<head>
	<title>Data Base</title>
	<style>
	</style>
</head>
<body>
	<h1>Delete</h1>
	<?php
	// Create connection 
	include("01connect.php");
	// Operate over Data Base
	// ......................................//
	// Insert table 
	$student = $_REQUEST['student'];
	$sql="DELETE FROM  student WHERE id =".$student;
	echo $sql."<br/>";
	if (mysqli_query($con,$sql))  {  
		echo "Deleted row successfully";  
	} else  {  
		echo "Error deleting row: " . mysqli_error($con);  
	} 
	// ......................................//
	mysqli_close($con);
	?>
</body>
</html>