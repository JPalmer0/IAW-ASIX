<!DOCTYPE html>
<html>
<head>
	<title>Data Base</title>
	<style>
	</style>
</head>
<body>
	<h1>Update Data Base (PHP).</h1>
	<?php
	// Create connection 
	include("01connect.php");
	// Operate over Data Base
	// ......................................//
	// Insert table 
	$student = $_REQUEST['student'];
	$name = $_REQUEST['name'];
	$surname = $_REQUEST['surname'];
	$age = $_REQUEST['age'];
	$sex = $_REQUEST['sex'];
	$sql="UPDATE  student SET  name='".$name."', surname='".$surname."', age='".$age."', sex='".$sex."' WHERE id =".$student;
	echo $sql."<br/>";
	if (mysqli_query($con,$sql))  {  
		echo "Updates row successfully";  
	} else  {  
		echo "Error updating row: " . mysqli_error($con);  
	} 
	// ......................................//
	mysqli_close($con);
	?>
</body>
</html>