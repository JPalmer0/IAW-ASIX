<!DOCTYPE html>
<html>
<head>
	<title>Data Base</title>
	<style>
	</style>
</head>
<body>
	<h1>Select</h1>
	<?php
	include("01connect.php");
	echo "<table border='1'>";
	echo "<tr><th>NAME</th><th>SURNAME</th><th>AGE</th></th><th>SEX</th></tr>";
	$sql="SELECT name, surname, age, sex FROM student
		ORDER BY age ASC"; 
	$rs = mysqli_query($con,$sql);
	while($row=mysqli_fetch_array($rs)){
		echo "<tr>";
			echo "<td>".$row['name']."</td>";
			echo "<td>".$row['surname']."</td>";
			echo "<td>".$row['age']."</td>";
			echo "<td>".$row['sex']."</td>";
		echo "</tr>";
	}
	echo "</table>";
	mysqli_close($con);
	?>
</body>
</html>