<!DOCTYPE html>
<html>
<head>
	<title>Data Base</title>
	<style>
	</style>
</head>
<body>
	<h1>Delete</h1>
	<form action="04deleteformB.php" method="GET">
		<?php
			include("01connect.php");
			echo "student:<select name='student'>";
			$sql="SELECT id, name FROM student"; 
			$rs = mysqli_query($con,$sql);
			while($row=mysqli_fetch_array($rs)){
				echo "<option value='".$row['id']."'>";
					echo $row['name'];
				echo "</option>";
			}
			echo "</select>";
		?><br/>
		<input type="submit" value="DELETE"/>
	</form>
</body>
</html>